package accountinfo.dao;

import org.durcframework.core.dao.BaseDao;
import accountinfo.entity.AccountInfo;

public interface AccountInfoDao extends BaseDao<AccountInfo> {
}