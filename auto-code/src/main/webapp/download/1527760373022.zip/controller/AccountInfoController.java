package com.coconason.snacksassistantaccountinfo.controller;

import com.coconason.snacksassistantcommon.model.SnacksResult;
import com.coconason.snacksassistantaccountinfo.service.IAccountInfoService;
import com.coconason.snacksassistantaccountinfo.vo.AccountInfoVo;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import javax.validation.constraints.Null;

@RestController
public class AccountInfoController {

    @Autowired
    IAccountInfoServiceaccountInfoService;

    //Get log4j2 object
    private static final Logger LOG = LogManager.getLogger(AccountInfoController.class);

    @ApiOperation(value="Add the information of the account_info", notes="")
    @RequestMapping(value="/add_account_info",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public SnacksResult addAccountInfoVo(@RequestBody @Validated AccountInfoVo accountInfoVo) throws Exception{
        SnacksResult snacksResult = accountInfoService.addAccountInfoVo(accountInfoVo);
        return snacksResult;
    }

    @ApiOperation(value="Delete the information of the account_info", notes="")
    @RequestMapping(value="/delete_account_info",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public SnacksResult deleteAccountInfoVo(@RequestParam @Null Long id) throws Exception{
        SnacksResult snacksResult = accountInfoService.deleteAccountInfoVo(id);
        return snacksResult;
    }

    @ApiOperation(value="Modify the information of the account_info", notes="")
    @RequestMapping(value="/set_account_info",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public SnacksResult setAccountInfoVo(@RequestBody @Validated AccountInfoVo accountInfoVo) throws Exception{
        SnacksResult snacksResult = accountInfoService.setAccountInfoVo(accountInfoVo);
        return snacksResult;
    }

    @ApiOperation(value="Query the information of the account_info", notes="")
    @RequestMapping(value="/get_account_info/{id}",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    public SnacksResult getAccountInfoVo(@PathVariable @Null Long id) throws Exception{
        AccountInfoVo accountInfoVo = accountInfoService.getAccountInfoVo(id);
        return new SnacksResult().ok(accountInfoVo);
    }
}
