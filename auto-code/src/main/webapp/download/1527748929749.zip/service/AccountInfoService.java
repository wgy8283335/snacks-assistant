package accountinfo.service;

import org.durcframework.core.service.CrudService;
import accountinfo.dao.AccountInfoDao;
import accountinfo.entity.AccountInfo;
import org.springframework.stereotype.Service;

@Service
public class AccountInfoService extends CrudService<AccountInfo, AccountInfoDao> {

}