package com.coconason.snacksassitant.service;

import org.durcframework.core.service.CrudService;
import com.coconason.snacksassitant.dao.AccountInfoDao;
import com.coconason.snacksassitant.entity.AccountInfo;
import org.springframework.stereotype.Service;

@Service
public class AccountInfoService extends CrudService<AccountInfo, AccountInfoDao> {

}