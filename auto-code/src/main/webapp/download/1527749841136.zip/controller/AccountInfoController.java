package com.coconason.snacksassitant.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.coconason.snacksassitant.entity.AccountInfo;
import com.coconason.snacksassitant.entity.AccountInfoSch;
import com.coconason.snacksassitant.service.AccountInfoService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AccountInfoController extends
		CrudController<AccountInfo, AccountInfoService> {

	@RequestMapping("/addAccountInfo.do")
	public ModelAndView addAccountInfo(AccountInfo entity) {
		return this.add(entity);
	}

	@RequestMapping("/listAccountInfo.do")
	public ModelAndView listAccountInfo(AccountInfoSch searchEntity) {
		return this.list(searchEntity);
	}

	@RequestMapping("/updateAccountInfo.do")
	public ModelAndView updateAccountInfo(AccountInfo entity) {
		return this.modify(entity);
	}

	@RequestMapping("/delAccountInfo.do")
	public ModelAndView delAccountInfo(AccountInfo entity) {
		return this.remove(entity);
	}
	
}