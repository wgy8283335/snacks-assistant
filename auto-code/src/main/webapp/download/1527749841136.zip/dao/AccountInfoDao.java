package com.coconason.snacksassitant.dao;

import org.durcframework.core.dao.BaseDao;
import com.coconason.snacksassitant.entity.AccountInfo;

public interface AccountInfoDao extends BaseDao<AccountInfo> {
}