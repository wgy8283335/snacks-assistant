package com.coconason.snacksassitant.entity;

/**
  
*/
public class AccountInfo {
	// 用户id号
	private Long id;
	// 登陆名(即手机号)
	private String loginName;
	// 用户密码(任意字符)
	private String password;
	// sa_user_info数据库的user_info表ID
	private Long userInfoId;
	// 是否删除该记录
	private Byte deleted;
	// 更新时间
	private Date updateTime;
	// 创建时间
	private Date createTime;

	public void setId(Long id){
		this.id = id;
	}

	public Long getId(){
		return this.id;
	}

	public void setLoginName(String loginName){
		this.loginName = loginName;
	}

	public String getLoginName(){
		return this.loginName;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return this.password;
	}

	public void setUserInfoId(Long userInfoId){
		this.userInfoId = userInfoId;
	}

	public Long getUserInfoId(){
		return this.userInfoId;
	}

	public void setDeleted(Byte deleted){
		this.deleted = deleted;
	}

	public Byte getDeleted(){
		return this.deleted;
	}

	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}

	public Date getUpdateTime(){
		return this.updateTime;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

}