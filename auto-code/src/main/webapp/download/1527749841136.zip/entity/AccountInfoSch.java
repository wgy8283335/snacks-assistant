package com.coconason.snacksassitant.entity;

import org.durcframework.core.expression.annotation.ValueField;
import org.durcframework.core.support.SearchBUI;

public class AccountInfoSch extends SearchBUI {

    private Long idSch;
    private String loginNameSch;
    private String passwordSch;
    private Long userInfoIdSch;
    private Byte deletedSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setLoginNameSch(String loginNameSch){
        this.loginNameSch = loginNameSch;
    }
    
    @ValueField(column = "login_name")
    public String getLoginNameSch(){
        return this.loginNameSch;
    }

    public void setPasswordSch(String passwordSch){
        this.passwordSch = passwordSch;
    }
    
    @ValueField(column = "password")
    public String getPasswordSch(){
        return this.passwordSch;
    }

    public void setUserInfoIdSch(Long userInfoIdSch){
        this.userInfoIdSch = userInfoIdSch;
    }
    
    @ValueField(column = "user_info_id")
    public Long getUserInfoIdSch(){
        return this.userInfoIdSch;
    }

    public void setDeletedSch(Byte deletedSch){
        this.deletedSch = deletedSch;
    }
    
    @ValueField(column = "deleted")
    public Byte getDeletedSch(){
        return this.deletedSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}